Obs, segment2features och im2segment ligger i mappen inl.... som också finns i denna zip-fil

